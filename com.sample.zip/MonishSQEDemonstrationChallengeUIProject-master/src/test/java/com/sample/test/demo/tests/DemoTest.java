package com.sample.test.demo.tests;

import POM.ImplementationClass.PizzaOrderPageImpl;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.sample.test.demo.TestBase;

import java.util.regex.Pattern;


public class DemoTest extends TestBase {

    @Test(groups = { "basic"})
    public void demoTest() {
        System.out.println("HELLO WORLD");
    }

    //  1. To verify if we can select any item from drop down menu for Pizza 1, Toppings 1 && Toppings 2.
    @Test(groups = { "selection"})
    public void verifyDropdownSelectionOfPizza() {

        PizzaOrderPageImpl pizzaOrderPage = new PizzaOrderPageImpl();
        // reset page
        pizzaOrderPage.clickResetButton();
        // Select dropdown of pizza
        pizzaOrderPage.selectPizza1(2);
        String value1 = pizzaOrderPage.getCurrentPizza1Value();
        // Select dropdown of pizza
        pizzaOrderPage.selectPizza1(3);
        String value2 = pizzaOrderPage.getCurrentPizza1Value();
        // Assertion
        Assert.assertFalse(value1.equalsIgnoreCase(value2), "Dropdown menu selection failed");
    }

    //   2. To verify if Quantity field only accepts integer values and no special characters or alphabets
    @Test(groups = { "validation"})
    public void verifyQuantityFieldInput() {

        PizzaOrderPageImpl pizzaOrderPage = new PizzaOrderPageImpl();
        // reset page
        pizzaOrderPage.clickResetButton();

        Pattern regex = Pattern.compile("[$&+,:;=\\\\?@#|/'<>.^*()%!-^A-Za-z]");

        String currentValue = pizzaOrderPage.getCurrentQuantityValueDisplayed();

        // Enter quantity integer
        pizzaOrderPage.enterQuantity("2");
        Assert.assertFalse(currentValue.contains(regex.pattern()), INPUT_CONTAINS_CHARACTERS_OTHER_THAN_INTEGERS);

        // Enter quantity integer
        pizzaOrderPage.clickResetButton();
        pizzaOrderPage.enterQuantity("abc");
        currentValue = pizzaOrderPage.getCurrentQuantityValueDisplayed();
        Assert.assertFalse(currentValue.contains(regex.pattern()), INPUT_CONTAINS_CHARACTERS_OTHER_THAN_INTEGERS);
    }


    // 3. To verify if Quantity field size only accepts 5 integer values and no special characters or alphabets
    @Test(groups = { "validation"})
    public void verifyQuantityFieldInputSize() {

        PizzaOrderPageImpl pizzaOrderPage = new PizzaOrderPageImpl();
        // reset page
        pizzaOrderPage.clickResetButton();
        // Enter quantity integer size 9
        pizzaOrderPage.enterQuantity("012345678");
        String currentValue = pizzaOrderPage.getCurrentQuantityValueDisplayed();
        int sizeOfcurrentValue = currentValue.split("").length;
        Assert.assertTrue(sizeOfcurrentValue == 5, "Input size is not as expected");
    }


    // 4. To verify the cost only shows numeric values , but not alphabetical values.( negative test case, when we add alphabets to quantity field)
    @Test(groups = { "validation"})
    public void verifyCostFieldInput() {

        String inputValue = "10";
        PizzaOrderPageImpl pizzaOrderPage = new PizzaOrderPageImpl();
        int a = 0;
        float b = 0;

        // test case 1
        // reset page
        pizzaOrderPage.clickResetButton();
        pizzaOrderPage.selectPizza1(2);
        // Enter quantity input value as a integer value
        pizzaOrderPage.enterQuantity("" + inputValue);
        String currentValue = pizzaOrderPage.getCurrentCostFieldValue();
        if (a == Integer.parseInt(currentValue)) {
            Assert.assertTrue(a == (int) a, "Not an integer value");
        }

        // test case 2
        inputValue = "123";
        pizzaOrderPage.clickResetButton();
        pizzaOrderPage.selectPizza1(2);
        // Enter quantity input value as a integer value
        pizzaOrderPage.enterQuantity("" + inputValue);
        currentValue = pizzaOrderPage.getCurrentCostFieldValue();
        if (b == Float.parseFloat(currentValue)) {
            Assert.assertTrue(b == (float) b, "Not an float value");
        }
    }


    // 5. To verify Cost field is Read only and cannot be edited.
    @Test(groups = { "validation"})
    public void verifyCostFieldPermissions() {

        PizzaOrderPageImpl pizzaOrderPage = new PizzaOrderPageImpl();
        // reset page
        pizzaOrderPage.clickResetButton();
        // Enter quantity integer size 9
        pizzaOrderPage.enterQuantity("10");
        Assert.assertFalse(pizzaOrderPage.sendCostFieldInputValue("abc").equalsIgnoreCase("abc"), "Cost field is NOT read only field");
    }


    // 6. To verify if cost field is showing correct total for orders being edited.
    @Test(groups = { "validation"})
    public void verifyCalcuationOfCostsForAnOrder() {

        PizzaOrderPageImpl pizzaOrderPage = new PizzaOrderPageImpl();
        String costvalue = "";
        int quantity = 11;
        // reset page
        pizzaOrderPage.clickResetButton();
        pizzaOrderPage.selectPizza1(1);
        pizzaOrderPage.enterQuantity("" + quantity);
        costvalue = pizzaOrderPage.getCurrentPizza1Value().trim().split("\\$")[1];
        float calculatedValue = pizzaOrderPage.calculateCost(costvalue, quantity);
        String displayedCostValue = pizzaOrderPage.getCurrentCostFieldValue();
        float displayedValue = Float.parseFloat(displayedCostValue);
        Assert.assertTrue(calculatedValue == displayedValue, "Calculated cost is INCORRECT");
    }


    //  7. To verify name text box can accept any characters like numbers, special sysmbols etc
    @Test(groups = { "validation"})
    public void verifyNameTextboxInput() {

        PizzaOrderPageImpl pizzaOrderPage = new PizzaOrderPageImpl();
        // reset page
        pizzaOrderPage.clickResetButton();

        pizzaOrderPage.enterNameFieldText("abc");
        // to Refresh the page with input values
        pizzaOrderPage.clickCostTextBox();
        String currentNameValue = pizzaOrderPage.getNameFieldTextValue();
        Assert.assertTrue(currentNameValue.equalsIgnoreCase("abc"),INPUT_VALUE_DOES_NOT_MATCH);

        pizzaOrderPage.enterNameFieldText("123");
        // to Refresh the page with input values
        pizzaOrderPage.clickCostTextBox();
        currentNameValue = pizzaOrderPage.getNameFieldTextValue();
        Assert.assertTrue(currentNameValue.equalsIgnoreCase("123"),INPUT_VALUE_DOES_NOT_MATCH);

        pizzaOrderPage.enterNameFieldText("abc_123");
        // to Refresh the page with input values
        pizzaOrderPage.clickCostTextBox();
        currentNameValue = pizzaOrderPage.getNameFieldTextValue();
        Assert.assertTrue(currentNameValue.equalsIgnoreCase("abc_123"),INPUT_VALUE_DOES_NOT_MATCH);

        pizzaOrderPage.enterNameFieldText("@#$%%");
        // to Refresh the page with input values
        pizzaOrderPage.clickCostTextBox();
        currentNameValue = pizzaOrderPage.getNameFieldTextValue();
        Assert.assertTrue(currentNameValue.equalsIgnoreCase("@#$%%"),INPUT_VALUE_DOES_NOT_MATCH);

    }

    //  8. To verify  we can Place order only when we enter name and phone number.
    @Test(groups = { "orders"})
    public void verifyCreatingNewOrder() {

        String success_Message = "Thank you for your order! TOTAL: 0";
        PizzaOrderPageImpl pizzaOrderPage = new PizzaOrderPageImpl();
        // reset page
        pizzaOrderPage.clickResetButton();
        pizzaOrderPage.enterNameFieldText("xyz");
        pizzaOrderPage.enterPhoneNumberFieldText("0929939390");
        pizzaOrderPage.clickPlaceOrderButton();
        Assert.assertTrue(pizzaOrderPage.isAlertPresent(), "Alert NOT present");
        String alertTextValue = pizzaOrderPage.getAlertText();
        Assert.assertTrue(success_Message.equalsIgnoreCase(alertTextValue), "Success dialog message incorrect");
    }

    @Test(groups = { "orders"})
    public void verifyCreatingOrderWithNullValues() {

        String error_Message = "Missing name\nMissing phone number";
        PizzaOrderPageImpl pizzaOrderPage = new PizzaOrderPageImpl();
        // reset page
        pizzaOrderPage.clickResetButton();
        pizzaOrderPage.enterNameFieldText("");
        pizzaOrderPage.enterPhoneNumberFieldText("");
        pizzaOrderPage.clickPlaceOrderButton();
        Assert.assertTrue(pizzaOrderPage.isAlertPresent(), "Alert NOT present");
        String alertTextValue = pizzaOrderPage.getAlertText();
        Assert.assertTrue(error_Message.equalsIgnoreCase(alertTextValue), "Error dialog message incorrect");
    }

    // 1. To verify the cost only shows numeric values , but not alphabetical values.( negative test case, when we add alphabets to quantity field)

    @Test(groups = { "validation"})
    public void verifyCostFieldValue() {
        String inputValue = "10";
        PizzaOrderPageImpl pizzaOrderPage = new PizzaOrderPageImpl();
        inputValue = "abc";
        pizzaOrderPage.clickResetButton();
        pizzaOrderPage.selectPizza1(2);
        // Enter quantity input value as a integer value
        pizzaOrderPage.enterQuantity("" + inputValue);
        String currentValue = pizzaOrderPage.getCurrentCostFieldValue();
        try {
            // checking valid integer using parseInt() method
            Integer.parseInt(currentValue);
            System.out.println(currentValue + " is a valid integer number");
        } catch (NumberFormatException e) {
            System.out.println(currentValue + " is not a valid integer number");
        }
    }

    //  2. To verify Email field only accepts valid email addresses.( example xyz@gmail.com)

    @Test(groups = { "validation"})
    public void verifyEmailTextboxInputValues() {
        PizzaOrderPageImpl pizzaOrderPage = new PizzaOrderPageImpl();
        // reset page
        pizzaOrderPage.clickResetButton();
        pizzaOrderPage.enterEmailFieldText("abc@gmail.com");
        // to Refresh the page with input values
        pizzaOrderPage.clickCostTextBox();
        String currentEmailFieldValue = pizzaOrderPage.getEmailFieldTextValue();
        Assert.assertTrue(currentEmailFieldValue.equalsIgnoreCase("abc@gmail.com"),INPUT_VALUE_DOES_NOT_MATCH);
        pizzaOrderPage.enterEmailFieldText("abc");
        // to Refresh the page with input values
        pizzaOrderPage.clickCostTextBox();
        currentEmailFieldValue = pizzaOrderPage.getEmailFieldTextValue();
        Assert.assertFalse(currentEmailFieldValue.equalsIgnoreCase("abc"), "Email text field accepting wrong input");
    }

//  3. To verify Phone number field only accepts numeric values.

    @Test(groups = { "validation"})
    public void verifyPhoneNumbersTextboxInputValues() {

        PizzaOrderPageImpl pizzaOrderPage = new PizzaOrderPageImpl();
        // reset page
        pizzaOrderPage.clickResetButton();
        Pattern regex = Pattern.compile("[$&+,:;=\\\\?@#|/'<>.^*()%!-^A-Za-z]");
        String currentValue = pizzaOrderPage.getCurrentQuantityValueDisplayed();
        // Enter Numeric input
        pizzaOrderPage.enterPhoneNumberFieldText("7846657744");
        Assert.assertFalse(currentValue.contains(regex.pattern()), INPUT_CONTAINS_CHARACTERS_OTHER_THAN_INTEGERS);
        // Enter Alphabet
        pizzaOrderPage.enterPhoneNumberFieldText("abcdef");
        Assert.assertFalse(currentValue.contains(regex.pattern()), INPUT_CONTAINS_CHARACTERS_OTHER_THAN_INTEGERS);
        // Enter Special characters
        pizzaOrderPage.enterPhoneNumberFieldText("@#$%^&*");
        Assert.assertFalse(currentValue.contains(regex.pattern()), INPUT_CONTAINS_CHARACTERS_OTHER_THAN_INTEGERS);
        // Enter size more than 10
        pizzaOrderPage.enterPhoneNumberFieldText("7846657744123");
        Assert.assertFalse(currentValue.contains(regex.pattern()), INPUT_CONTAINS_CHARACTERS_OTHER_THAN_INTEGERS);
    }

    @Test(groups = { "orders"})
    public void verifyCreatingNewOrderwithAllValues() {

        PizzaOrderPageImpl pizzaOrderPage = new PizzaOrderPageImpl();
        // reset page
        pizzaOrderPage.clickResetButton();
        pizzaOrderPage.selectPizza1(3);
        pizzaOrderPage.selectToppings1(2);
        pizzaOrderPage.selectToppings2(3);
        pizzaOrderPage.enterQuantity("1");
        pizzaOrderPage.enterNameFieldText("testName");
        pizzaOrderPage.enterEmailFieldText("test@xyz.com");
        pizzaOrderPage.enterPhoneNumberFieldText("0989897354");
        String orderValue = pizzaOrderPage.getCurrentPizza1Value().split("\\$")[0].replace("\n", "").trim();
        String costvalue = pizzaOrderPage.getCurrentPizza1Value().trim().split("\\$")[1];
        float calculatedValue = pizzaOrderPage.calculateCost(costvalue, 1);

        String displayedCostValue = pizzaOrderPage.getCurrentCostFieldValue();
        float displayedValue = Float.parseFloat(displayedCostValue);
        Assert.assertTrue(calculatedValue == displayedValue, "Calculated cost is INCORRECT");

        pizzaOrderPage.selectCreditCardRadioButton();

            pizzaOrderPage.clickPlaceOrderButton();
        String success_Message = "Thank you for your order! TOTAL: " + "" + displayedValue + " " + orderValue;
        success_Message = success_Message.replace(" ", "").trim();
        Assert.assertTrue(pizzaOrderPage.isAlertPresent(), "Alert NOT present");
        String alertTextValue = pizzaOrderPage.getAlertText().replace(" ", "").trim();
        Assert.assertTrue(success_Message.equalsIgnoreCase(alertTextValue), "Success dialog message incorrect");
    }
}

