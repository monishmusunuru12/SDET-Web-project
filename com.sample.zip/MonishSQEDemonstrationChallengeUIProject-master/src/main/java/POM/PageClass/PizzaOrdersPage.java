package POM.PageClass;

public class PizzaOrdersPage implements PizzaOrders {
    @Override
    public void clickResetButton() {

    }

    @Override
    public void clickPlaceOrderButton() {

    }

    @Override
    public void selectCreditCardRadioButton() {

    }

    @Override
    public void selectPayByCashRadioButton() {

    }

    @Override
    public void enterNameFieldText(String inputValue) {

    }

    @Override
    public String getNameFieldTextValue() {
        return null;
    }

    @Override
    public void enterEmailFieldText(String inputValue) {

    }

    @Override
    public boolean isValid(String email) {
        return false;
    }

    @Override
    public String getEmailFieldTextValue() {
        return null;
    }

    @Override
    public void enterPhoneNumberFieldText(String inputValue) {

    }

    @Override
    public boolean validatePhoneNumber(String phoneNo) {
        return false;
    }

    @Override
    public String getCurrentPhoneNumberValueDisplayed() {
        return null;
    }

    @Override
    public void enterQuantity(String inputValue) {

    }

    @Override
    public String getCurrentQuantityValueDisplayed() {
        return null;
    }

    @Override
    public void selectPizza1(int inputValue) {

    }

    @Override
    public void selectToppings1(int inputValue) {

    }

    @Override
    public void selectToppings2(int inputValue) {

    }

    @Override
    public String getCurrentPizza1Value() {
        return null;
    }

    @Override
    public String getCurrentCostFieldValue() {
        return null;
    }

    @Override
    public void clickCostTextBox() {

    }

    @Override
    public String sendCostFieldInputValue(String value) {
        return null;
    }

    @Override
    public float calculateCost(String value, int quantity) {
        return 0;
    }

    @Override
    public boolean isAlertPresent() {
        return false;
    }

    @Override
    public String getAlertText() {
        return null;
    }
}
