package POM.PageClass;

public interface PizzaOrders {

    public void clickResetButton();

    public void clickPlaceOrderButton();

    public void selectCreditCardRadioButton();

    public void selectPayByCashRadioButton();

    public void enterNameFieldText(String inputValue);

    public String getNameFieldTextValue();

    public void enterEmailFieldText(String inputValue);

    public boolean isValid(String email);

    public String getEmailFieldTextValue();

    public void enterPhoneNumberFieldText(String inputValue);

    public boolean validatePhoneNumber(String phoneNo);

    public String getCurrentPhoneNumberValueDisplayed();

    public void enterQuantity(String inputValue);

    public String getCurrentQuantityValueDisplayed();

    public void selectPizza1(int inputValue);

    public void selectToppings1(int inputValue);

    public void selectToppings2(int inputValue);

    public String getCurrentPizza1Value();

    public String getCurrentCostFieldValue();

    public void clickCostTextBox();

    public String sendCostFieldInputValue(String value);

    public float calculateCost(String value, int quantity);

    public boolean isAlertPresent();

    public String getAlertText();
}
