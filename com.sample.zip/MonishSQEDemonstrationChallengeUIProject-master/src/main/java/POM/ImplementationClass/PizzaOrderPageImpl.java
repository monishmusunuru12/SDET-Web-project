package POM.ImplementationClass;

import POM.PageClass.PizzaOrders;
import com.google.common.base.Preconditions;
import com.sample.test.demo.TestBase;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.util.regex.Pattern;

public class PizzaOrderPageImpl extends TestBase implements PizzaOrders {

@Override
    public void clickResetButton() {
        WebElement resetButton = null;
        try {
            resetButton = driver.findElement(By.id("" + pizzaLocators.getLocator("resetButton", path)));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        resetButton.click();
    }
    @Override
    public void clickPlaceOrderButton() {
        WebElement placeOrderButton = null;
        try {
            placeOrderButton = driver.findElement(By.id("" + pizzaLocators.getLocator("placeOrderButton", path)));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        placeOrderButton.click();
    }
    @Override
    public void selectCreditCardRadioButton() {
        WebElement creditCardRadioButton = null;
        try {
            creditCardRadioButton = driver.findElement(By.id("" + pizzaLocators.getLocator("radioCreditCard", path)));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        creditCardRadioButton.click();
    }
    @Override
    public void selectPayByCashRadioButton() {
        WebElement creditCardRadioButton = null;
        try {
            creditCardRadioButton = driver.findElement(By.id("" + pizzaLocators.getLocator("radioCash", path)));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        creditCardRadioButton.click();
    }
    @Override
    public void enterNameFieldText(String inputValue) {
        WebElement nameFieldText = null;
        try {
            nameFieldText = driver.findElement(By.id("" + pizzaLocators.getLocator("name", path)));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        nameFieldText.clear();
        nameFieldText.sendKeys(inputValue);
    }
    @Override
    public String getNameFieldTextValue() {
        WebElement nameFieldText = null;
        String defaultItem = "";
        try {
            nameFieldText = driver.findElement(By.id("" + pizzaLocators.getLocator("name", path)));
            defaultItem = nameFieldText.getAttribute("value");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return defaultItem;
    }
    @Override
    public void enterEmailFieldText(String inputValue) {
        WebElement emailFieldText = null;
        try {
            emailFieldText = driver.findElement(By.id("" + pizzaLocators.getLocator("email", path)));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        emailFieldText.clear();
        Preconditions.checkArgument(isValid(inputValue), "Invalid Email Address");
        emailFieldText.sendKeys(inputValue);
    }
    @Override
    public boolean isValid(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\." +
                "[a-zA-Z0-9_+&*-]+)*@" +
                "(?:[a-zA-Z0-9-]+\\.)+[a-z" +
                "A-Z]{2,7}$";

        Pattern pat = Pattern.compile(emailRegex);
        if (email == null)
            return false;
        return pat.matcher(email).matches();
    }
    @Override
    public String getEmailFieldTextValue() {
        String defaultItem = "";
        WebElement emailFieldText = null;
        try {
            emailFieldText = driver.findElement(By.id("" + pizzaLocators.getLocator("email", path)));
            defaultItem = emailFieldText.getAttribute("value");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return defaultItem;
    }

    @Override
    public void enterPhoneNumberFieldText(String inputValue) {
        WebElement phoneNumberFieldText = null;
        try {
            phoneNumberFieldText = driver.findElement(By.id("" + pizzaLocators.getLocator("phone", path)));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        phoneNumberFieldText.sendKeys(inputValue);
        clickCostTextBox();
        Preconditions.checkArgument(validatePhoneNumber(inputValue), "Invalid Phone number");

    }

    @Override
    public boolean validatePhoneNumber(String phoneNo) {
        //validate phone numbers of format "1234567890"
        if (phoneNo.matches("\\d{10}")) return true;
            //validating phone number with -, . or spaces
        else if (phoneNo.matches("\\d{3}[-\\.\\s]\\d{3}[-\\.\\s]\\d{4}")) return true;
            //return false if nothing matches the input
        else return false;

    }
    @Override
    public String getCurrentPhoneNumberValueDisplayed() {
        WebElement phoneNumberFieldText = null;
        String defaultItem = "";
        try {
            phoneNumberFieldText = driver.findElement(By.id("" + pizzaLocators.getLocator("phone", path)));
            defaultItem = phoneNumberFieldText.getAttribute("value");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return defaultItem;
    }
    @Override
    public void enterQuantity(String inputValue) {
        WebElement enterQuantityFieldText = null;
        try {
            enterQuantityFieldText = driver.findElement(By.id("" + pizzaLocators.getLocator("pizza1Quantity", path)));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        enterQuantityFieldText.clear();
        enterQuantityFieldText.sendKeys(inputValue);
        enterQuantityFieldText.click();
    }
    @Override
    public String getCurrentQuantityValueDisplayed() {
        WebElement enterQuantityFieldText = null;
        String defaultItem = "";
        try {
            enterQuantityFieldText = driver.findElement(By.id("" + pizzaLocators.getLocator("pizza1Quantity", path)));
            defaultItem = enterQuantityFieldText.getAttribute("value");

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return defaultItem;
    }

    @Override
    public void selectPizza1(int inputValue) {
        if (inputValue == 0) {
            throw new InputMismatchException("Invalid input value");
        }
        Select selectPizza = null;
        try {
            selectPizza = new Select(driver.findElement(By.id("" + pizzaLocators.getLocator("pizza1", path))));
            selectPizza.selectByIndex(inputValue);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void selectToppings1(int inputValue) {
        if (inputValue == 0) {
            throw new InputMismatchException("Invalid input value");
        }
        Select selectToppings = null;
        try {
            selectToppings = new Select(driver.findElement(By.xpath("" + pizzaLocators.getLocator("pizza1Toppings1", path))));
            selectToppings.selectByIndex(inputValue);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void selectToppings2(int inputValue) {
        if (inputValue == 0) {
            throw new InputMismatchException("Invalid input value");
        }
        Select selectToppings = null;
        try {
            selectToppings = new Select(driver.findElement(By.xpath("" + pizzaLocators.getLocator("pizza1Toppings2", path))));
            selectToppings.selectByIndex(inputValue);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    @Override
    public String getCurrentPizza1Value() {
        Select currentPizza1Value = null;
        String defaultItem = "";
        try {
            currentPizza1Value = new Select(driver.findElement(By.id("" + pizzaLocators.getLocator("pizza1", path))));
            WebElement option = currentPizza1Value.getFirstSelectedOption();
            defaultItem = option.getText();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return defaultItem;
    }

    @Override
    public String getCurrentCostFieldValue() {
        WebElement currentCostFieldValue = null;
        String defaultItem = "";
        try {
            currentCostFieldValue = driver.findElement(By.id("" + pizzaLocators.getLocator("pizza1Cost", path)));
            currentCostFieldValue.click();
            defaultItem = currentCostFieldValue.getAttribute("value");

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return defaultItem;
    }

    @Override
    public void clickCostTextBox() {
        try {
            WebElement currentCostFieldValue = driver.findElement(By.id("" + pizzaLocators.getLocator("pizza1Cost", path)));
            currentCostFieldValue.click();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
    @Override
    public String sendCostFieldInputValue(String value) {
        WebElement currentCostFieldValue = null;
        String defaultItem = "";
        try {
            currentCostFieldValue = driver.findElement(By.id("" + pizzaLocators.getLocator("pizza1Cost", path)));
            currentCostFieldValue.sendKeys(value);
            defaultItem = currentCostFieldValue.getAttribute("value");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return defaultItem;
    }

    @Override
    public float calculateCost(String value, int quantity) {
        float valueToint = Float.parseFloat(value);
        return valueToint * quantity;
    }
    @Override
    public boolean isAlertPresent() {
        try {
            WebElement alert = driver.findElement(By.id("" + pizzaLocators.getLocator("alert", path)));
            alert.isDisplayed();
            return true;
        }// try
        catch (Exception e) {
            return false;
        }
    }
    @Override
    public String getAlertText() {
        String alertTextValue = "";
        try {
            WebElement alertText = driver.findElement(By.id("" + pizzaLocators.getLocator("alert_Text", path)));
            alertTextValue = alertText.getText();
            return alertTextValue;
        } catch (Exception e) {
            return alertTextValue;
        }
    }
}
