package com.sample.test.demo.constants;

import org.json.simple.parser.JSONParser;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;

public class PizzaLocators {
    Object obj;
    String val;

    public String getLocator(String name, String locatorFilepath) throws FileNotFoundException {

        //JSON parser object to parse read file
        JSONParser jsonParser = new JSONParser();

        FileReader reader = new FileReader("" + locatorFilepath);
        {
            //Read JSON file
            try {
                obj = jsonParser.parse(reader);
                JSONObject objJ = (JSONObject) obj;

                JSONObject locator = (JSONObject) objJ.get(name);

                if (locator.keySet().toString().contains("id")) {
                    val = (String) locator.get("id");
                } else if (locator.keySet().toString().contains("xpath")) {
                    val = (String) locator.get("xpath");
                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        return val;
    }

}