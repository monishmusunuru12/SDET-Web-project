package com.sample.test.demo;

import static org.testng.Assert.fail;

import com.sample.test.demo.constants.PizzaLocators;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import java.io.FileNotFoundException;
import java.util.concurrent.TimeUnit;

public class TestBase {

    private Configuration config;
    public static WebDriver driver = null;
    protected String url;
    public static final String INPUT_CONTAINS_CHARACTERS_OTHER_THAN_INTEGERS= "Input contains Characters other than integers";

    public static final String INPUT_VALUE_DOES_NOT_MATCH= "Input contains Characters other than integers";


    public PizzaLocators pizzaLocators = new PizzaLocators();
    static Configuration configuration = new Configuration();
    public static String path = configuration.getLocatorFilePath();



    @BeforeClass(alwaysRun = true)
    public void init() throws Throwable {
        config = new Configuration();
        url = config.getUrl();
        initializelDriver();
        navigateToSite();
        waitUntilPageLoads();
    }

    public void waitUntilPageLoads() {
        try {
            driver.findElement(By.id("" + pizzaLocators.getLocator("resetButton", path)));

            driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
    private void navigateToSite() {
        driver.get(url);
        driver.manage().window().maximize();
    }

    @AfterClass(alwaysRun = true)
    public void tearDown() {
        try {
            driver.quit();

        } catch (Exception e) {
        }
    }

    private void initializelDriver() {
        if (config.getBrowser().equalsIgnoreCase("chrome")) {
            if (config.getPlatform().equalsIgnoreCase("mac")) {
                System.setProperty("webdriver.chrome.driver", "src/test/resources/chromedriver/mac/chromedriver");
                config.getLocatorFilePath();
            } else {
                System.setProperty("webdriver.chrome.driver",
                        "src/test/resources/chromedriver/windows/chromedriver.exe");
            }
            driver = new ChromeDriver();
        } else {
            fail("Unsupported browser " + config.getBrowser());
        }

    }
}
