## Demo Challange


#### Project Setup
1. Clone this project.
2. Setup the project in your IDE.
3. Open the index.html file from src/test/resource/files in a browser
4. Copy the url from the browser and update the url value in src/test/resource/config.properties to be the copied url.
5. In src/test/resources update the config.properties file platform for your OS.
6. From command line run mvn clean install -U -DskipTests
7. Make sure you can run the DemoTest and chrome launches.  You may need to update the chromedriver in /src/test/resources/chromedriver/ to the version that works with your browser
   https://chromedriver.chromium.org/

#### Expectations
We will be evaluating
1. Quality of test cases
2. Variety  of testing types (examples: boundary, happy path, negative, etc)
3. Code structure and organization
4. Naming conventions
5. Code readability
6. Code modularity

#### Excercise
1. Use the site at the index.html
2. There are helper locators provided for you in the src/test/resource/files/locators.txt file.
3. In the Read me file, write up all of the test cases you think are necessary to test the sample page.
4. Code up a few examples of 
  - At least one happy path case placing an order
  - At least one error case
5. When complete please check your code into a public git repo

#### Test Cases

 1. To verify if we can select any item from drop down menu for Pizza 1, Toppings 1 && Toppings 2.
 2. To verify if Quantity field only accepts integer values and no special characters or alphabets
 2. To verify if Quantity field size only accepts 3 integer values and no special characters or alphabets
 3. To verify the cost only shows numeric values , but not alphabetical values.( negative test case, when we add alphabets to quantity field)
 4. To verify Cost field is Read only and cannot be edited.
 5. To verify if cost field is showing correct total for orders being edited.
 5. To verify name text box can accept any characters like numbers, special sysmbols etc
 6. To verify Email field only accepts valid email addresses.( example xyz@gmail.com)
 7. To verify Phone number field only accepts numeric values.
 8. To verify we can only select one radio button while checking out ( Credit card or cash )
 9. To verify  we can Place order only when we enter name and phone number.
 10. To verify the correct error message in the box while we try to enter invalid details while placing order
 11. To verify if error message is dismissable
 12. To verify the functionlity of reset button is actually clearing all the fields on the page
 13. To verify if we select no toppings from pizza dropdown menu, and select the toppings 1 and 2 from bottom and place an order. order should not consist of toppings in it
 14. to verify different scenarios of selecting dropdowns from menu and checking the order message contains everything in it. ( example toppings, pizza and cost )
 15. To verify we can place order only if we select atleast one radio button
 16. To verify if we select credit card , we should get text fields to enter and validate the credit card data.
 17. Check if after placing an order the page gets automaticaaly reset.
 18. Verify when we chose a pizza no toppings, we should not get an option to select toppings after that.
 19. Verify appropriate count of toppings are selected based on pizza selection.



